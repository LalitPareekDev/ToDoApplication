module.exports = {
    target: 'node',
    mode: 'none'
}