module.exports.TaskStatus = {
    DRAFT: "Draft",
    ASSIGNED: "Assigned",
    INPROGRESS: "In-Progress",
    COMPLETED: "Completed",
    CLOSED: "Closed"
},
module.exports.SecretKey = "hgsdjadhfkjfhkjfhdskj"